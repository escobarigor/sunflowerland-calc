# 🌻 SFL EcoCalculator

Calculadora de economia (não-oficial) para **Sunflower Land** — expansões,
plantações, recursos e mais. Site estático, sem build, feito para hospedar
no **GitHub Pages**.

## Estrutura

```
sfl-ecocalculator/
├── index.html        → estrutura + navegação das abas
├── css/style.css     → visual (tema fazenda, claro/escuro)
└── js/
    ├── data.js       → dados FIXOS do jogo (custos, recursos)
    ├── api.js        → camada de dados — único arquivo que fala com a API
    ├── calc.js       → lógica de cálculo (funções puras)
    ├── tabs.js       → troca de abas
    └── app.js        → ponto de entrada, desenha as abas
```

## Status (roadmap)

- [x] Esqueleto + navegação de abas
- [x] Aba **Expansão** (totais por ilha)
- [x] Aba **Plantações** (23 crops — lucro/hora)
- [x] Aba **Recursos** (respawn e rendimento/dia)
- [x] Aba **Cozinha** (83 receitas — XP/hora)
- [x] Aba **Config** — salvar/apagar chave de API
- [x] **Onda 1 completa** — dados do código-fonte oficial do jogo
- [ ] Custo de expansão por nível (hoje só o total por ilha)
- [ ] Onda 2: abas Resumo e Inventário (usam a chave de API)
- [ ] Confirmar API: endpoint exato, header da chave, e se há CORS

## Rodar localmente

Por causa de `fetch`, abra com um servidor (não pelo `file://`):

```bash
python3 -m http.server 8000
# abra http://localhost:8000
```

## Publicar no GitHub Pages

1. Crie um repositório (ex.: `sfl-ecocalculator`) e suba estes arquivos.
2. Repositório → **Settings → Pages**.
3. Em *Source*, escolha a branch `main` e a pasta `/ (root)`.
4. Salve. A URL fica `https://SEU-USUARIO.github.io/sfl-ecocalculator/`.

## Aviso

Projeto comunitário, sem afiliação com o Sunflower Land. Os dados de jogo
são preenchidos manualmente a partir de fontes públicas e podem ficar
desatualizados a cada Chapter.
